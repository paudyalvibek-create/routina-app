"use strict";(()=>{var e={};e.id=105,e.ids=[105],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2615:e=>{e.exports=require("http")},5240:e=>{e.exports=require("https")},8621:e=>{e.exports=require("punycode")},6162:e=>{e.exports=require("stream")},7360:e=>{e.exports=require("url")},1568:e=>{e.exports=require("zlib")},37:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>k,patchFetch:()=>y,requestAsyncStorage:()=>h,routeModule:()=>m,serverHooks:()=>g,staticGenerationAsyncStorage:()=>f});var a={};r.r(a),r.d(a,{PUT:()=>u});var i=r(757),n=r(2378),o=r(1963),s=r(5176),l=r(3131),p=r(5202),d=r(3081);function c(e){let[t,r]=e.split(":").map(Number);return 60*t+r}async function u(e){try{let t=e.headers.get("authorization");if(!t)return s.NextResponse.json({error:"Unauthorized"},{status:401});let r=t.replace("Bearer ",""),{data:{user:a},error:i}=await p.p.auth.getUser(r);if(i||!a)return s.NextResponse.json({error:"Unauthorized"},{status:401});let{date:n}=await e.json(),o=await l._.plan.findFirst({where:{userId:a.id,date:new Date(n)}});if(!o)return s.NextResponse.json({error:"Plan not found for this date"},{status:404});let u=await l._.preferences.findFirst({where:{userId:a.id}});if(!u)return s.NextResponse.json({error:"Preferences not found"},{status:400});let m=function(){let e=new Date;return`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`}(),h=c(m),f=o.blocks.filter(e=>e.completed||c(e.endTime)<=h),g=f.map(e=>e.activity),k=await (0,d.K)({role:u.role||"professional",goals:u.goals||[],constraints:u.constraintsList||[],focusAreas:u.focusAreas||[],wakeTime:u.wakeTime||"06:00",sleepTime:u.sleepTime||"22:00",timezone:u.timezone||"UTC",currentTime:m,completedBlocks:g}),y=[...f,...k.filter(e=>c(e.startTime)>=h)],w=y.filter(e=>e.completed).length/y.length*100,T=await l._.plan.update({where:{id:o.id},data:{blocks:y,completionRate:Math.round(100*w)/100}});return s.NextResponse.json({data:{plan:T,blocks:y}})}catch(e){return s.NextResponse.json({error:"Failed to replan",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let m=new i.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/plan/replan/route",pathname:"/api/plan/replan",filename:"route",bundlePath:"app/api/plan/replan/route"},resolvedPagePath:"/workspace/routina/app/api/plan/replan/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:h,staticGenerationAsyncStorage:f,serverHooks:g}=m,k="/api/plan/replan/route";function y(){return(0,o.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:f})}},3081:(e,t,r)=>{r.d(t,{K:()=>s});var a=r(2079);let i=process.env.GEMINI_API_KEY,n=new a.$D(i),o={student:`You are an AI routine planner for students. Create a balanced daily schedule that includes:
- Study sessions with breaks (Pomodoro technique)
- Time for classes and assignments
- Physical activity and exercise
- Meals and rest periods
- Social and recreational activities
- Adequate sleep schedule`,professional:`You are an AI routine planner for working professionals. Create a productive schedule that includes:
- Focused work blocks with breaks
- Meeting slots and collaboration time
- Email and communication management
- Professional development
- Exercise and wellness activities
- Work-life balance with personal time`,creator:`You are an AI routine planner for creators and artists. Create an inspiring schedule that includes:
- Deep work sessions for creative projects
- Skill development and learning
- Content creation and publishing
- Marketing and audience engagement
- Rest and inspiration time
- Physical and mental wellness`,fitness:`You are an AI routine planner for fitness enthusiasts. Create an optimal schedule that includes:
- Workout sessions (strength, cardio, flexibility)
- Meal prep and nutrition planning
- Recovery and rest periods
- Active recovery activities
- Sleep optimization
- Hydration and wellness tracking`};async function s(e){let t=n.getGenerativeModel({model:"gemini-2.0-flash-exp"}),r=o[e.role]||o.professional,a=`${r}

User Profile:
- Role: ${e.role}
- Goals: ${e.goals.join(", ")}
- Constraints: ${e.constraints.join(", ")}
- Focus Areas: ${e.focusAreas.join(", ")}
- Wake Time: ${e.wakeTime}
- Sleep Time: ${e.sleepTime}
- Timezone: ${e.timezone}
${e.currentTime?`- Current Time: ${e.currentTime} (re-planning from this point)`:""}
${e.completedBlocks?.length?`- Already Completed: ${e.completedBlocks.join(", ")}`:""}

Create a detailed daily routine with specific time blocks. Each block should have:
- Unique ID (use format: block-1, block-2, etc.)
- Start time (HH:MM format in 24-hour)
- End time (HH:MM format in 24-hour)
- Activity name (concise, actionable)
- Description (brief, 1-2 sentences explaining the activity)
- Category (one of: work, study, fitness, personal, break, sleep)
- Priority (one of: high, medium, low)

${e.currentTime?`Start from ${e.currentTime} and plan the rest of the day. Preserve completed activities and adjust remaining schedule.`:`Plan from ${e.wakeTime} to ${e.sleepTime}.`}

IMPORTANT: Respond ONLY with valid JSON array of blocks. No explanations, no markdown formatting, just the JSON array.

Example format:
[
  {
    "id": "block-1",
    "startTime": "06:00",
    "endTime": "06:30",
    "activity": "Morning Routine",
    "description": "Wake up, freshen up, and prepare for the day",
    "category": "personal",
    "priority": "high",
    "completed": false
  }
]`;try{let e=(await t.generateContent(a)).response.text().trim();e.startsWith("```json")?e=e.replace(/```json\n?/g,"").replace(/```\n?/g,""):e.startsWith("```")&&(e=e.replace(/```\n?/g,""));let r=JSON.parse(e);if(!Array.isArray(r))throw Error("Invalid response: not an array");return r.forEach((e,t)=>{if(!e.id||!e.startTime||!e.endTime||!e.activity||!e.category)throw Error(`Invalid block at index ${t}: missing required fields`)}),r}catch(t){return[{id:"block-1",startTime:e.wakeTime,endTime:l(e.wakeTime,30),activity:"Morning Routine",description:"Wake up, freshen up, and prepare for the day",category:"personal",priority:"high",completed:!1},{id:"block-2",startTime:l(e.wakeTime,30),endTime:l(e.wakeTime,60),activity:"Breakfast",description:"Healthy breakfast to start the day",category:"personal",priority:"high",completed:!1},{id:"block-3",startTime:l(e.wakeTime,60),endTime:l(e.wakeTime,150),activity:"Focused Work Block",description:"Deep work on priority tasks",category:"student"===e.role?"study":"work",priority:"high",completed:!1}]}}function l(e,t){let[r,a]=e.split(":").map(Number),i=60*r+a+t;return`${String(Math.floor(i/60)%24).padStart(2,"0")}:${String(i%60).padStart(2,"0")}`}},3131:(e,t,r)=>{r.d(t,{_:()=>i});let a=require("@prisma/client"),i=globalThis.prisma??new a.PrismaClient},5202:(e,t,r)=>{r.d(t,{p:()=>n});var a=r(3916);let i=process.env.SUPABASE_SERVICE_ROLE_KEY,n=(0,a.eI)("https://mdnellbxsuwhrlwinfrn.supabase.co",i,{auth:{autoRefreshToken:!1,persistSession:!1}})}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[622,672,79],()=>r(37));module.exports=a})();